/**
 * Safety Tutorial — HTML5/SCORM 1.2 player
 *
 * Loads course content from JSON files in /content/, renders slides one by one,
 * tracks user interactions, and reports completion + score to a parent LMS
 * via the SCORM 1.2 API (window.API discovered in the parent frame chain).
 *
 * Editing the tutorial:
 *   - Texts:        edit content/slides/<slideId>.json (the `text` of each choice, the `title`)
 *   - Slide order:  edit content/course.json (the `slides` array)
 *   - Pass rule:    edit content/course.json (quiz.passPercent)
 *
 * No build step. Just edit the JSON, re-zip, re-upload.
 */

// ============================================================
// SCORM 1.2 API wrapper (finds the LMS-provided API, falls back to no-op)
// ============================================================
const Scorm = (function () {
  let api = null;
  let initialized = false;
  let active = false;

  function findAPI(win) {
    let depth = 0;
    while (win && depth < 50) {
      if (win.API) return win.API;
      if (win.parent === win) break;
      win = win.parent;
      depth++;
    }
    return null;
  }

  function init() {
    try {
      api = findAPI(window) || (window.opener && findAPI(window.opener));
    } catch (e) { api = null; }
    if (!api) {
      console.warn('[SCORM] No LMS API found — running standalone.');
      return false;
    }
    const ok = api.LMSInitialize('');
    initialized = (ok === 'true' || ok === true);
    active = initialized;
    if (initialized) {
      console.log('[SCORM] Connected. Status:', api.LMSGetValue('cmi.core.lesson_status'));
      // Mark started
      const st = api.LMSGetValue('cmi.core.lesson_status');
      if (st === 'not attempted' || st === '') {
        api.LMSSetValue('cmi.core.lesson_status', 'incomplete');
      }
    }
    return initialized;
  }

  function set(k, v) {
    if (!active) return false;
    return api.LMSSetValue(k, String(v)) === 'true';
  }

  function commit() { if (active) api.LMSCommit(''); }

  function finish() {
    if (!active) return;
    api.LMSCommit('');
    api.LMSFinish('');
    active = false;
  }

  // Window close / navigate-away safety: always Finish so the LMS records the session.
  window.addEventListener('beforeunload', () => { if (active) finish(); });
  window.addEventListener('pagehide',     () => { if (active) finish(); });

  return { init, set, commit, finish, get isActive() { return active; } };
})();

// ============================================================
// Content loader
// ============================================================
async function loadCourse() {
  const course = await fetch('content/course.json').then(r => r.json());
  course.slidesData = [];
  for (const ref of course.slides) {
    const sl = await fetch('content/' + ref.file).then(r => r.json());
    course.slidesData.push(sl);
  }
  return course;
}

// ============================================================
// Renderer
// ============================================================
function makeAssetPath(slideImage) {
  // Image asset filenames in our zip are normalized to `asset_<id>.<ext>`
  // (see extract.py). slideImage.url is the original Storyline path.
  const ext = slideImage.url.split('.').pop();
  return `content/assets/asset_${slideImage.assetId}.${ext}`;
}

function renderTitle(slide) {
  const img = slide.images[0];
  const imgTag = img ? `<img src="${makeAssetPath(img)}" alt="">` : '';
  return `
    <div class="title-slide">
      ${imgTag}
      <h1>${escapeHtml(slide.title)}</h1>
      <div class="subtitle">לחצו "שקף הבא" כדי להתחיל</div>
    </div>`;
}

function renderChecklist(slide) {
  const img = slide.images[0];
  const imgBlock = img
    ? `<div class="slide-image"><img src="${makeAssetPath(img)}" alt=""></div>`
    : '';
  const items = slide.choices.map((c, i) => `
    <label class="check-item" data-id="${c.id}">
      <input type="checkbox" data-choice-id="${c.id}">
      <span class="check-text">${escapeHtml(c.text)}</span>
    </label>`).join('');
  return `
    <div class="slide-title">${escapeHtml(slide.title)}</div>
    <div class="checklist-layout">
      <div class="checklist">${items}</div>
      ${imgBlock}
    </div>`;
}

function renderResults(slide, passed, scorePct) {
  const cls = passed ? 'passed' : 'failed';
  const heading = passed ? 'סיימת בהצלחה!' : 'לא חתמת על כל הנקודות';
  const passingPct = State.course.quiz.passPercent;
  const passingPoints = Math.ceil(State.totalPoints * passingPct / 100);
  return `
    <div class="results-slide ${cls}">
      <h2>${heading}</h2>
      <dl class="score-table" aria-label="Quiz score">
        <div class="score-row">
          <dt>Your Score:</dt>
          <dd>${scorePct}% (${State.earnedPoints} points)</dd>
        </div>
        <div class="score-row">
          <dt>Passing Score:</dt>
          <dd>${passingPct}% (${passingPoints} points)</dd>
        </div>
      </dl>
    </div>`;
}

function escapeHtml(s) {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

// ============================================================
// State machine
// ============================================================
const State = {
  course: null,
  currentIndex: 0,
  slideChecks: {},   // slideId → Set of checked choice IDs
  awardedSlideIds: new Set(),
  totalPoints: 0,
  earnedPoints: 0,
};

function totalMaxPoints(course) {
  return course.slidesData
    .filter(s => course.quiz.scoredSlideIds.includes(s.id))
    .reduce((sum, s) => sum + (s.maxPoints || 0), 0);
}

function updateProgress() {
  const total = State.course.slidesData.length;
  const n = State.currentIndex + 1;
  document.getElementById('slide-counter').textContent = `${n}/${total}`;
}

function renderCurrent() {
  const slide = State.course.slidesData[State.currentIndex];
  const container = document.getElementById('slide-container');
  const nextBtn = document.getElementById('next-btn');
  const prevBtn = document.getElementById('prev-btn');
  const notice = document.getElementById('notice');
  const nav = document.querySelector('.slide-nav');
  notice.classList.remove('visible');
  if (nav) nav.hidden = false;

  prevBtn.disabled = State.currentIndex === 0;
  nextBtn.disabled = false;
  nextBtn.textContent = 'שקף הבא';
  prevBtn.textContent = 'שקף קודם';

  // Update SCORM location bookmark so user resumes here
  Scorm.set('cmi.core.lesson_location', slide.id);

  if (slide.type === 'title') {
    container.innerHTML = renderTitle(slide);
    nextBtn.disabled = false;
  } else if (slide.type === 'checklist') {
    container.innerHTML = renderChecklist(slide);
    nextBtn.disabled = true;
    wireChecklist(slide);
    // Restore previously-checked state if user came back
    const prev = State.slideChecks[slide.id];
    if (prev) {
      prev.forEach(cid => {
        const cb = container.querySelector(`input[data-choice-id="${cid}"]`);
        if (cb) { cb.checked = true; cb.closest('.check-item').classList.add('checked'); }
      });
      checkAllChecked(slide);
    }
  } else if (slide.type === 'results') {
    const pct = State.totalPoints
      ? Math.round(State.earnedPoints / State.totalPoints * 100)
      : 0;
    const passed = pct >= State.course.quiz.passPercent;
    container.innerHTML = renderResults(slide, passed, pct);
    nextBtn.disabled = true;
    prevBtn.disabled = true;
    if (nav) nav.hidden = true;
    finalizeScorm(passed, pct);
  } else {
    // future: 'content' type slides without checks
    container.innerHTML = `<div class="slide-title">${escapeHtml(slide.title)}</div>`;
    nextBtn.disabled = false;
  }

  updateProgress();
}

function wireChecklist(slide) {
  const container = document.getElementById('slide-container');
  container.querySelectorAll('.check-item').forEach(item => {
    const cb = item.querySelector('input[type="checkbox"]');
    item.addEventListener('click', (e) => {
      // Avoid double-toggle when the native checkbox itself was clicked
      if (e.target !== cb) cb.checked = !cb.checked;
      item.classList.toggle('checked', cb.checked);

      const set = State.slideChecks[slide.id] || new Set();
      if (cb.checked) set.add(cb.dataset.choiceId);
      else set.delete(cb.dataset.choiceId);
      State.slideChecks[slide.id] = set;

      checkAllChecked(slide);
    });
  });
}

function checkAllChecked(slide) {
  const set = State.slideChecks[slide.id] || new Set();
  const allChecked = set.size === slide.choices.length;
  document.getElementById('next-btn').disabled = !allChecked;
}

function advance() {
  const slide = State.course.slidesData[State.currentIndex];

  // Award points if this is a scored checklist that is fully checked
  if (slide.type === 'checklist') {
    const set = State.slideChecks[slide.id] || new Set();
    const isScored = State.course.quiz.scoredSlideIds.includes(slide.id);
    const isComplete = set.size === slide.choices.length;
    if (isComplete && isScored && !State.awardedSlideIds.has(slide.id)) {
      State.awardedSlideIds.add(slide.id);
      State.earnedPoints += slide.maxPoints || 0;
      // Report this interaction to the LMS (SCORM 1.2 interactions are 0-indexed)
      const ix = State.course.quiz.scoredSlideIds.indexOf(slide.id);
      Scorm.set(`cmi.interactions.${ix}.id`, slide.interactionId || slide.id);
      Scorm.set(`cmi.interactions.${ix}.type`, 'choice');
      Scorm.set(`cmi.interactions.${ix}.student_response`,
                slide.choices.map(c => c.id).join(','));
      Scorm.set(`cmi.interactions.${ix}.result`, 'correct');
      Scorm.commit();
    }
  } else if (slide.type === 'results') {
    Scorm.finish();
    // Try to close the LMS window if possible (Moodle handles this gracefully)
    if (window.parent && window.parent !== window) {
      try { window.parent.postMessage({ type: 'scorm-complete' }, '*'); } catch (e) {}
    }
    return;
  }

  if (State.currentIndex < State.course.slidesData.length - 1) {
    State.currentIndex++;
    renderCurrent();
  }
}

function previousSlide() {
  if (State.currentIndex > 0) {
    State.currentIndex--;
    renderCurrent();
  }
}

function finalizeScorm(passed, pct) {
  // Report the LMS score as a percentage, not as earned checklist points.
  // Example: full completion returns 100 instead of 29.
  Scorm.set('cmi.core.score.raw', String(pct));
  Scorm.set('cmi.core.score.min', '0');
  Scorm.set('cmi.core.score.max', '100');
  Scorm.set('cmi.core.lesson_status', passed ? 'passed' : 'failed');
  Scorm.commit();
}

// ============================================================
// Boot
// ============================================================
(async function main() {
  Scorm.init();

  try {
    State.course = await loadCourse();
  } catch (e) {
    document.getElementById('slide-container').innerHTML =
      '<div style="padding:40px;color:#c25a3a">שגיאת טעינת תוכן: ' + e.message + '</div>';
    return;
  }

  const courseTitleEl = document.getElementById('course-title');
  if (courseTitleEl) courseTitleEl.textContent = State.course.title;
  document.title = State.course.title;
  State.totalPoints = totalMaxPoints(State.course);

  // Resume from bookmark if SCORM provided one
  if (Scorm.isActive) {
    // Note: Scorm.set returns true/false, but we want to read. Use the raw API for reads:
    // (kept simple — only writes are wrapped in Scorm.set)
  }

  document.getElementById('next-btn').addEventListener('click', advance);
  document.getElementById('prev-btn').addEventListener('click', previousSlide);
  renderCurrent();
})();
