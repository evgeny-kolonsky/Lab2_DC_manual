/**
 * DC1 Hebrew — HTML5/SCORM 1.2 player (v2 skeleton).
 *
 * Slide types:
 *   "title"     : cover slide with title + subtitle + body paragraphs + icon row
 *   "content"   : informational slide with title + body + image grid (large or normal)
 *   "questions" : 1+ interactive questions on one slide (mixed types allowed)
 *   "hotspot"   : single hotspot question — image-centric layout, clickable regions
 *   "results"   : final score
 *
 * Question types (inside `questions[]` or `question`):
 *   "numeric"  : free-form numeric input, scored by ±tolerance vs target
 *   "dropdown" : pick one from a list, scored by exact match
 *   "hotspot"  : pick N regions on an image, scored by exact set match
 *
 * Each question carries 1 point. Course % = correct / total questions.
 * Pass threshold from course.json (quiz.passPercent, default 80).
 * Free navigation: user may move between slides at any time and retry answers.
 */

// ============================================================
// SCORM 1.2 wrapper
// ============================================================
const Scorm = (function () {
  let api = null, initialized = false, active = false;
  function findAPI(win) {
    let depth = 0;
    while (win && depth < 50) {
      if (win.API) return win.API;
      if (win.parent === win) break;
      win = win.parent; depth++;
    }
    return null;
  }
  function init() {
    try { api = findAPI(window) || (window.opener && findAPI(window.opener)); }
    catch (e) { api = null; }
    if (!api) { console.info('[SCORM] No LMS API — standalone mode.'); return false; }
    const ok = api.LMSInitialize('');
    initialized = (ok === 'true' || ok === true);
    active = initialized;
    if (initialized) {
      const st = api.LMSGetValue('cmi.core.lesson_status');
      if (st === 'not attempted' || st === '') {
        api.LMSSetValue('cmi.core.lesson_status', 'incomplete');
      }
    }
    return initialized;
  }
  function set(k, v) { if (!active) return false; return api.LMSSetValue(k, String(v)) === 'true'; }
  function commit() { if (active) api.LMSCommit(''); }
  function finish() { if (!active) return; api.LMSCommit(''); api.LMSFinish(''); active = false; }
  window.addEventListener('beforeunload', () => { if (active) finish(); });
  window.addEventListener('pagehide',     () => { if (active) finish(); });
  return { init, set, commit, finish, get isActive() { return active; } };
})();

// ============================================================
// Loader
// ============================================================
async function loadCourse() {
  const course = await fetch('content/course.json').then(r => r.json());
  course.slidesData = [];
  for (const ref of course.slides) {
    const sl = await fetch('content/' + ref.file).then(r => r.json());
    course.slidesData.push(sl);
  }
  return course;
}

// ============================================================
// State
// ============================================================
const State = {
  course: null,
  currentIndex: 0,
  /** per-question answers, keyed by `${slideId}::${questionId}` → { value, correct } */
  answers: {},
};

function esc(s) {
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

/**
 * Inline rendering: escape HTML, then convert `**text**` to <strong>text</strong>
 * and `*text*` (single) to <em>text</em>. This is the safe path for any user text.
 */
function renderInline(s) {
  if (s == null) return '';
  let out = esc(s);
  out = out.replace(/\*\*([^*\n]+)\*\*/g, '<strong>$1</strong>');
  out = out.replace(/(^|[^*])\*([^*\n]+)\*([^*]|$)/g, '$1<em>$2</em>$3');
  return out;
}

function assetPath(name) {
  return `content/assets/${name}`;
}

// ============================================================
// Score
// ============================================================
function allQuestions() {
  const list = [];
  for (const sl of State.course.slidesData) {
    if (sl.type === 'questions' && Array.isArray(sl.questions)) {
      for (const q of sl.questions) list.push({ slide: sl, question: q });
    } else if (sl.type === 'hotspot' && sl.question) {
      list.push({ slide: sl, question: sl.question });
    }
  }
  return list;
}

function recomputeScore() {
  const all = allQuestions();
  if (all.length === 0) return { earned: 0, total: 0, pct: 0 };
  let earned = 0;
  for (const { slide, question } of all) {
    const key = `${slide.id}::${question.id}`;
    if (State.answers[key]?.correct) earned++;
  }
  const total = all.length;
  const pct = Math.round(earned / total * 100);
  return { earned, total, pct };
}

// ============================================================
// Question evaluation
// ============================================================
function evaluateQuestion(question, rawValue) {
  if (question.type === 'numeric') {
    const v = parseFloat(String(rawValue).replace(',', '.'));
    if (!isFinite(v)) return { correct: false, reason: 'invalid' };
    if (question.target == null) return { correct: false, reason: 'no-target' };
    const target = Number(question.target);
    const tol = question.tolerance ?? 0.1;
    const isRelative = question.toleranceType === 'relative';
    const bound = isRelative ? Math.abs(target) * tol : tol;
    return { correct: Math.abs(v - target) <= bound + 1e-9 };
  }
  if (question.type === 'dropdown' || question.type === 'pick-one') {
    return { correct: String(rawValue) === String(question.correctId) };
  }
  if (question.type === 'hotspot') {
    // rawValue should be an array of selected region IDs
    const selected = Array.isArray(rawValue) ? rawValue : [];
    const correct = Array.isArray(question.correctIds) ? question.correctIds : [];
    const mode = question.evaluation || 'exactSet';
    if (mode === 'exactSet') {
      const a = new Set(selected), b = new Set(correct);
      if (a.size !== b.size) return { correct: false };
      for (const x of a) if (!b.has(x)) return { correct: false };
      return { correct: true };
    }
    if (mode === 'subset') {
      // every selected must be in correct
      return { correct: selected.every(x => correct.includes(x)) };
    }
    return { correct: false };
  }
  return { correct: false, reason: 'unknown type' };
}

// ============================================================
// Default feedback text (when question doesn't define its own)
// ============================================================
const DEFAULT_FEEDBACK = {
  correct: 'נכון! 🎉',
  incorrect: 'יש לך טעות… נסה שוב.'
};
function feedbackText(question, isCorrect) {
  const f = question.feedback || {};
  if (isCorrect) return f.correct || DEFAULT_FEEDBACK.correct;
  return f.incorrect || DEFAULT_FEEDBACK.incorrect;
}

// ============================================================
// Renderers
// ============================================================
function renderTitle(slide) {
  const bodyParas = (slide.body || []).map(p => `<p>${renderInline(p)}</p>`).join('');
  const items = (slide.items || []).map(it => `
    <figure class="title-item">
      ${it.imageUrl ? `<img src="${assetPath(it.imageUrl)}" alt="${esc(it.altText || it.label || '')}">` : ''}
      <figcaption>${renderInline(it.label || '')}</figcaption>
    </figure>`).join('');
  const subtitle = slide.subtitle ? `<div class="title-subtitle">${renderInline(slide.subtitle)}</div>` : '';
  return `
    <header class="title-header">
      <h1>${esc(slide.title)}</h1>
      ${subtitle}
    </header>
    ${bodyParas ? `<div class="title-body">${bodyParas}</div>` : ''}
    ${items ? `<div class="title-items">${items}</div>` : ''}`;
}

function renderContent(slide) {
  const paras = (slide.body || []).map(p => `<p>${renderInline(p)}</p>`).join('');
  // Detect if items are "large" — affects grid template
  const anyLarge = (slide.items || []).some(i => i.size === 'large');
  const gridCls = anyLarge ? 'content-grid content-grid-large' : 'content-grid';
  const items = (slide.items || []).map(it => `
    <figure class="content-item ${it.size === 'large' ? 'content-item-large' : ''}">
      ${it.imageUrl ? `<img src="${assetPath(it.imageUrl)}" alt="${esc(it.altText || it.label || '')}">` : ''}
      <figcaption>${renderInline(it.label || '')}</figcaption>
    </figure>`).join('');
  return `
    ${slide.title ? `<div class="slide-title">${esc(slide.title)}</div>` : ''}
    ${paras ? `<div class="content-body">${paras}</div>` : ''}
    ${items ? `<div class="${gridCls}">${items}</div>` : ''}`;
}

function renderContentSteps(slide) {
  const paras = (slide.body || []).map(p => `<p>${renderInline(p)}</p>`).join('');
  const steps = slide.steps || [];
  const buttonsHtml = steps.map((s, i) =>
    `<button class="step-btn ${i === 0 ? 'step-btn-active' : ''}" data-step-idx="${i}" type="button">${esc(s.label)}</button>`
  ).join('');
  const firstImg = steps[0]?.imageUrl;
  return `
    ${slide.title ? `<div class="slide-title">${esc(slide.title)}</div>` : ''}
    <div class="content-steps">
      ${paras ? `<div class="steps-body">${paras}</div>` : ''}
      <div class="steps-stage">
        <div class="step-buttons">${buttonsHtml}</div>
        <div class="step-image-wrap">
          ${firstImg ? `<img class="step-image" src="${assetPath(firstImg)}" alt="">` : '<div class="step-empty">— no image —</div>'}
        </div>
      </div>
    </div>`;
}

function wireContentSteps(slide) {
  const container = document.getElementById('slide-container');
  const stage = container.querySelector('.content-steps');
  if (!stage) return;
  const img = stage.querySelector('.step-image');
  const btns = stage.querySelectorAll('.step-btn');
  btns.forEach(b => {
    b.addEventListener('click', () => {
      const idx = parseInt(b.dataset.stepIdx, 10);
      const step = (slide.steps || [])[idx];
      if (!step || !img) return;
      img.src = assetPath(step.imageUrl);
      btns.forEach(x => x.classList.remove('step-btn-active'));
      b.classList.add('step-btn-active');
    });
  });
}

function renderQuestions(slide) {
  const img = slide.images?.[0];
  const imgBlock = img ? `<div class="slide-image"><img src="${assetPath(img.imageUrl)}" alt="${esc(img.altText || '')}"></div>` : '';
  const qsHtml = (slide.questions || []).map(q => renderOneQuestion(slide, q)).join('');
  return `
    ${slide.title ? `<div class="slide-title">${esc(slide.title)}</div>` : ''}
    <div class="questions-layout ${img ? 'has-image' : ''}">
      <div class="questions-col">${qsHtml}</div>
      ${imgBlock}
    </div>`;
}

function renderOneQuestion(slide, q) {
  const key = `${slide.id}::${q.id}`;
  const stored = State.answers[key];
  const fbCls   = stored ? (stored.correct ? 'fb-correct' : 'fb-wrong') : '';
  const fbText  = stored ? feedbackText(q, stored.correct) : '';
  // Prompt may be a string or array of paragraphs
  const promptHtml = renderPrompt(q.prompt);

  if (q.type === 'dropdown' || q.type === 'pick-one') {
    const opts = ['<option value="">— בחרו תשובה —</option>',
      ...q.options.map(o =>
        `<option value="${esc(o.id)}" ${stored?.value === o.id ? 'selected' : ''}>${esc(o.text)}</option>`
      )].join('');
    return `
      <div class="question" data-qid="${esc(q.id)}" data-qtype="${esc(q.type)}">
        ${promptHtml}
        <div class="q-row">
          <select class="q-select">${opts}</select>
          <button class="btn-check" type="button">בדוק</button>
        </div>
        <div class="q-feedback ${fbCls}">${esc(fbText)}</div>
      </div>`;
  }

  if (q.type === 'numeric') {
    const lbl = q.label ? `<div class="q-label">${esc(q.label)}</div>` : '';
    return `
      <div class="question" data-qid="${esc(q.id)}" data-qtype="${esc(q.type)}">
        ${promptHtml}
        ${lbl}
        <div class="q-row">
          <input class="q-numeric" type="text" inputmode="decimal"
                 value="${stored?.value != null ? esc(stored.value) : ''}"
                 placeholder="הכנס תשובה">
          ${q.unit ? `<span class="q-unit">${esc(q.unit)}</span>` : ''}
          <button class="btn-check" type="button">בדוק</button>
        </div>
        <div class="q-feedback ${fbCls}">${esc(fbText)}</div>
      </div>`;
  }

  return `<div class="question">[unsupported question type: ${esc(q.type)}]</div>`;
}

function renderPrompt(prompt) {
  if (!prompt) return '';
  if (Array.isArray(prompt)) {
    return `<div class="q-prompt">${prompt.map(p => `<p>${renderInline(p)}</p>`).join('')}</div>`;
  }
  return `<div class="q-prompt">${renderInline(prompt)}</div>`;
}

function renderHotspot(slide) {
  const q = slide.question;
  const key = `${slide.id}::${q.id}`;
  const stored = State.answers[key];
  const selected = stored && Array.isArray(stored.value) ? new Set(stored.value) : new Set();
  const fbCls  = stored ? (stored.correct ? 'fb-correct' : 'fb-wrong') : '';
  const fbText = stored ? feedbackText(q, stored.correct) : '';

  const regionsHtml = q.regions.map(r => `
    <button type="button"
            class="hotspot ${selected.has(r.id) ? 'hotspot-selected' : ''}"
            data-rid="${esc(r.id)}"
            style="left:${r.xPct}%; top:${r.yPct}%; width:${r.sizePct}%;"
            aria-label="hotspot ${esc(r.id)}"
            aria-pressed="${selected.has(r.id) ? 'true' : 'false'}">
      <span class="hotspot-check" aria-hidden="true">✓</span>
    </button>`).join('');

  return `
    <div class="slide-title">${esc(slide.title)}</div>
    ${renderPrompt(slide.prompt)}
    <div class="hotspot-stage" data-qid="${esc(q.id)}">
      <div class="hotspot-imagewrap">
        <img src="${assetPath(slide.image.imageUrl)}" alt="${esc(slide.image.altText || '')}">
        ${regionsHtml}
      </div>
      <div class="hotspot-controls">
        <button class="btn-check btn-check-large" type="button">בדוק</button>
      </div>
      <div class="q-feedback ${fbCls}">${esc(fbText)}</div>
    </div>`;
}

function renderResults(slide) {
  const { earned, total, pct } = recomputeScore();
  const passingPct = State.course.quiz.passPercent;
  const passed = pct >= passingPct;
  const L = slide.labels || {};
  const headline = passed ? (L.passedHeadline || 'סיימת בהצלחה!') : (L.failedHeadline || 'לא הגעת לציון העובר');
  const body = passed ? (L.passedBody || '') : (L.failedBody || '');
  const yourScoreLbl = L.yourScore || 'הניקוד שלך:';
  const passLbl = L.passingScore || 'ניקוד עובר:';
  const bodyHtml = body
    ? `<div class="results-body">${body.split('\n').map(line => `<p>${esc(line)}</p>`).join('')}</div>`
    : '';
  return `
    <div class="results-slide ${passed ? 'passed' : 'failed'}">
      <h2>${esc(headline)}</h2>
      <dl class="score-table">
        <div class="score-row"><dt>${esc(yourScoreLbl)}</dt><dd>${pct}% (${earned}/${total})</dd></div>
        <div class="score-row"><dt>${esc(passLbl)}</dt><dd>${passingPct}%</dd></div>
      </dl>
      ${bodyHtml}
    </div>`;
}

// ============================================================
// Wiring
// ============================================================
function wireQuestions(slide) {
  const container = document.getElementById('slide-container');
  container.querySelectorAll('.question').forEach(qEl => {
    const qid = qEl.dataset.qid;
    const q = slide.questions.find(x => x.id === qid);
    const btn = qEl.querySelector('.btn-check');
    if (!btn) return;
    btn.addEventListener('click', () => {
      let raw;
      if (q.type === 'numeric') {
        raw = qEl.querySelector('.q-numeric').value.trim();
      } else {
        raw = qEl.querySelector('.q-select').value;
      }
      if (raw === '' || raw == null) return;
      submitAnswer(slide, q, raw, qEl);
    });
  });
}

function wireHotspot(slide) {
  const container = document.getElementById('slide-container');
  const stage = container.querySelector('.hotspot-stage');
  if (!stage) return;
  const q = slide.question;
  const selected = new Set(
    State.answers[`${slide.id}::${q.id}`]?.value || []
  );

  stage.querySelectorAll('.hotspot').forEach(btn => {
    btn.addEventListener('click', () => {
      const rid = btn.dataset.rid;
      if (selected.has(rid)) {
        selected.delete(rid);
        btn.classList.remove('hotspot-selected');
        btn.setAttribute('aria-pressed', 'false');
      } else {
        selected.add(rid);
        btn.classList.add('hotspot-selected');
        btn.setAttribute('aria-pressed', 'true');
      }
    });
  });

  const checkBtn = stage.querySelector('.btn-check');
  checkBtn.addEventListener('click', () => {
    const arr = Array.from(selected);
    if (arr.length === 0) return;
    submitAnswer(slide, q, arr, stage);
  });
}

function submitAnswer(slide, q, rawValue, scopeEl) {
  const result = evaluateQuestion(q, rawValue);
  const key = `${slide.id}::${q.id}`;
  State.answers[key] = { value: rawValue, correct: !!result.correct };
  // Update feedback element within the scope
  const fb = scopeEl.querySelector('.q-feedback');
  if (fb) {
    fb.classList.remove('fb-correct', 'fb-wrong');
    fb.classList.add(result.correct ? 'fb-correct' : 'fb-wrong');
    fb.textContent = feedbackText(q, result.correct);
  }
  reportInteraction(slide, q, rawValue, result.correct);
}

function reportInteraction(slide, question, value, correct) {
  if (!Scorm.isActive) return;
  const all = allQuestions();
  const idx = all.findIndex(x => x.slide.id === slide.id && x.question.id === question.id);
  if (idx < 0) return;
  const iid = question.interactionId || `${slide.id}_${question.id}`;
  let itype, response, correctResp;
  if (question.type === 'numeric') {
    itype = 'numeric';
    response = String(value);
    correctResp = String(question.target);
  } else if (question.type === 'hotspot') {
    itype = 'matching';
    response = Array.isArray(value) ? value.join(',') : String(value);
    correctResp = (question.correctIds || []).join(',');
  } else {
    itype = 'choice';
    response = String(value);
    correctResp = String(question.correctId);
  }
  Scorm.set(`cmi.interactions.${idx}.id`, iid);
  Scorm.set(`cmi.interactions.${idx}.type`, itype);
  Scorm.set(`cmi.interactions.${idx}.student_response`, response);
  Scorm.set(`cmi.interactions.${idx}.result`, correct ? 'correct' : 'wrong');
  Scorm.set(`cmi.interactions.${idx}.correct_responses.0.pattern`, correctResp);
  Scorm.commit();
}

function renderCurrent() {
  const slide = State.course.slidesData[State.currentIndex];
  const container = document.getElementById('slide-container');
  const nextBtn = document.getElementById('next-btn');
  const prevBtn = document.getElementById('prev-btn');

  prevBtn.disabled = State.currentIndex === 0;
  nextBtn.disabled = false;
  nextBtn.textContent = 'שקף הבא';
  prevBtn.textContent = 'שקף קודם';
  Scorm.set('cmi.core.lesson_location', slide.id);

  // Reset class on slide for type-specific styling
  container.className = 'slide slide-' + slide.type;

  switch (slide.type) {
    case 'title':
      container.innerHTML = renderTitle(slide);
      break;
    case 'content':
      container.innerHTML = renderContent(slide);
      break;
    case 'content-steps':
      container.innerHTML = renderContentSteps(slide);
      wireContentSteps(slide);
      break;
    case 'questions':
      container.innerHTML = renderQuestions(slide);
      wireQuestions(slide);
      break;
    case 'hotspot':
      container.innerHTML = renderHotspot(slide);
      wireHotspot(slide);
      break;
    case 'results':
      container.innerHTML = renderResults(slide);
      finalizeScorm();
      nextBtn.disabled = true;
      prevBtn.disabled = false;
      nextBtn.textContent = '—';
      break;
    default:
      container.innerHTML = `<div class="slide-title">${esc(slide.title || '(no title)')}</div>
        <p style="padding:20px;color:#c25a3a">Unsupported slide type: ${esc(slide.type)}</p>`;
  }
  updateCounter();
}

function updateCounter() {
  const total = State.course.slidesData.length;
  const n = State.currentIndex + 1;
  document.getElementById('slide-counter').textContent = `${n}/${total}`;
}

function finalizeScorm() {
  const { pct } = recomputeScore();
  const passed = pct >= State.course.quiz.passPercent;
  Scorm.set('cmi.core.score.raw', String(pct));
  Scorm.set('cmi.core.score.min', '0');
  Scorm.set('cmi.core.score.max', '100');
  Scorm.set('cmi.core.lesson_status', passed ? 'passed' : 'failed');
  Scorm.commit();
}

function goNext() {
  if (State.currentIndex < State.course.slidesData.length - 1) {
    State.currentIndex++;
    renderCurrent();
  }
}
function goPrev() {
  if (State.currentIndex > 0) {
    State.currentIndex--;
    renderCurrent();
  }
}

// ============================================================
// Boot
// ============================================================
(async function main() {
  Scorm.init();
  try {
    State.course = await loadCourse();
  } catch (e) {
    document.getElementById('slide-container').innerHTML =
      `<div style="padding:40px;color:#c25a3a">שגיאת טעינת תוכן: ${esc(e.message)}</div>`;
    console.error(e);
    return;
  }
  document.title = State.course.title;
  document.getElementById('next-btn').addEventListener('click', goNext);
  document.getElementById('prev-btn').addEventListener('click', goPrev);
  renderCurrent();
})();
